import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 33;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // locationyAN (41:190)
        width: double.infinity,
        height: 12*fem,
        child: Text(
          'Location',
          style: SafeGoogleFont (
            'Inter',
            fontSize: 7.9999995232*ffem,
            fontWeight: FontWeight.w500,
            height: 1.4999999702*ffem/fem,
            letterSpacing: -0.0879999967*fem,
            color: Color(0xff1e1e1e),
          ),
        ),
      ),
          );
  }
}